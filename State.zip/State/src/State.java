interface State {
    void executar();
}