class EstadoA implements State {

    public void executar() {
        System.out.println("Executando no Estado A");
    }
}